﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eSolver.Entities.OutSideView
{
    public class OutsideOfViewRange
    {
        public List<ViewSchedule> ViewSchedules { get; set; }
    }
}
