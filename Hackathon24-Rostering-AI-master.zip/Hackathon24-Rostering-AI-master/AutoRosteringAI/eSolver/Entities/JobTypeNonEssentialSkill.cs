﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eSolver.Entities
{
    public class JobTypeNonEssentialSkill
    {
        
        public long SkillCodeID { get; set; }
        
        
        public long JobTypeID { get; set; }
        
        
        public string SkillGroup { get; set; }
        
    }
}
