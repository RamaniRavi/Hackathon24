﻿namespace eSolver.Entities
{
    public class SkillMatrix
    {
        public int EmployeeID { get; set; }
        public int SkillCodeID { get; set; }
        public bool Value { get; set; }
    }

}
