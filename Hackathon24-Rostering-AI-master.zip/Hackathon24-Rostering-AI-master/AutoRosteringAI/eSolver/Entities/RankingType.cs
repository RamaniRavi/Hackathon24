﻿namespace eSolver.Entities
{ 
    public class RankingType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
