﻿namespace eSolver.Entities.Constraints.Untiles
{
    public class ConstraintCustomRange
    {
        public int ConstraintID { get; set; }
        public int Offset { get; set; }
        public int Amount { get; set; }
        public int Id { get; set; }

    }
}
