﻿namespace eSolver.Entities.Constraints.Untiles
{
    public class ConstraintCustomData
    {
        public int ConstraintID { get; set; }
        public int CustomDataID { get; set; }
        public string Operator { get; set; }
        public string EmployeeField { get; set; }
        public object CustomData { get; set; }
        public int Id { get; set; }

    }
}
