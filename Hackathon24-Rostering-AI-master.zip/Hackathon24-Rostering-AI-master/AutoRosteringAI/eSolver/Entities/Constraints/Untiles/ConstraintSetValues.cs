﻿using System.Collections.Generic;

namespace eSolver.Entities.Constraints.Untiles
{
    public class ConstraintSetValues
    {
        public int ConstraintID { get; set; }
        public string Operator { get; set; }
        public string EmployeeField { get; set; }
        public string ComparisonValue { get; set; }
        public int Id { get; set; }

    }
}
