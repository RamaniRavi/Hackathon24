﻿using System;

namespace eSolver.Entities.Constraints.Untiles
{
    public class ConstraintBaseDateRange
    {
        public int ConstraintID { get; set; }
        public DateTime BaseDate { get; set; }
        public int BaseDateRange { get; set; }
        public int Id { get; set; }

    }
}
